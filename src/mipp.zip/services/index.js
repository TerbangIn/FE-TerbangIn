import * as authService from "./auth.service";
import * as storageService from "./storage.service";

export { authService, storageService };
