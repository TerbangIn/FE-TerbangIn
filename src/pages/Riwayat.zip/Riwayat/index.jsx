import { Outlet, Link } from "react-router-dom";

const Index = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Index;